
var config = {
        mode: "fixed_servers",
        rules: {
        singleProxy: {
            scheme: "socks5", /*如果使用的是http/https代理，这个值改为"http"即可*/
            host: "125.87.109.176",
            port: parseInt(16693)
        },
        bypassList: ["localhost"]
        }
    };

chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

function callbackFn(details) {
    return {
        authCredentials: {
            username: "treezeng",
            password: "nrfrqd5o"
        }
    };
}

chrome.webRequest.onAuthRequired.addListener(
            callbackFn,
            {urls: ["<all_urls>"]},
            ['blocking']
);
